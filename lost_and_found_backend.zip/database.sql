CREATE DATABASE lost_and_found;
USE lost_and_found;

CREATE TABLE claimer (
    claimer_id INT AUTO_INCREMENT PRIMARY KEY,
    firstname VARCHAR(100),
    lastname VARCHAR(100)
);

CREATE TABLE finder (
    finder_id INT AUTO_INCREMENT PRIMARY KEY,
    firstname VARCHAR(100),
    lastname VARCHAR(100),
    department VARCHAR(100)
);

CREATE TABLE item (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    item_name VARCHAR(255),
    description TEXT
);

CREATE TABLE found (
    found_id INT AUTO_INCREMENT PRIMARY KEY,
    item_id INT,
    room_no INT,
    finder_id INT,
    found_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (item_id) REFERENCES item(item_id),
    FOREIGN KEY (finder_id) REFERENCES finder(finder_id)
);

CREATE TABLE claimed_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    claimer_id INT,
    item_id INT,
    found_id INT,
    FOREIGN KEY (claimer_id) REFERENCES claimer(claimer_id),
    FOREIGN KEY (item_id) REFERENCES item(item_id),
    FOREIGN KEY (found_id) REFERENCES found(found_id)
);